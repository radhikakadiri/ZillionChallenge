package com.zchallenge;


import javax.ws.rs.Path;
import javax.ws.rs.core.Application;




@Path("/palindromes/")
public class RESTConfiguration extends Application {
	
}
	
	