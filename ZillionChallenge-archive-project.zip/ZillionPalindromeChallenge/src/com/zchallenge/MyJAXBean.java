package com.zchallenge;

import javax.xml.bind.annotation.XmlElement;
//import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
//import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement
public class MyJAXBean {
	public MyJAXBean() {} 
	 public MyJAXBean(String name, String count) {
	        this.name = name;
	        this.count = count;}
    @XmlElement(name="king")
    public String name;
 
    @XmlTransient
    public String count;
 
    // several lines removed
}

/*@XmlRootElement
public class MyJAXBean {
    public String name;
    public String count;
 
    public MyJAXBean() {} // JAXB needs this
 
    public MyJAXBean(String name, String count) {
        this.name = name;
        this.count = count;
    }
}
*/