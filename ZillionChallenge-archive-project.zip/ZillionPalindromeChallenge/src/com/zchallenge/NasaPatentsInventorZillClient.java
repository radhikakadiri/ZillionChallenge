package com.zchallenge;

/**
 * @author rkadiri
 *
 */

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import java.util.List;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import javax.ws.rs.client.Client; 
import org.json.JSONObject;
import org.junit.Test;
import org.apache.log4j.Logger;
import org.json.JSONArray;

public class NasaPatentsInventorZillClient {
	static Logger log = Logger.getLogger(NasaPatentsInventorZillClient.class);
	//public static void main(String[] args){
	public  HashMap<String, String> getInventorNamePalindrome(){
	//public  ArrayList<String> getInventorNamePalindrome(){
		//String temp = "";
		

		//1. Create a client
		Client client = ClientBuilder.newClient();
		
		
		//2. set a target to a client
		WebTarget target = client.target("http://api.data.gov/nasa/patents/content?query=electricity&limit=3&api_key=DEMO_KEY");
			
		//3. get response
		try{
		
		//String result = target.request(MediaType.APPLICATION_XML).get(String.class);
			
		/*USed the below hardcoded data for checking without connecting to the webservice as there is limiation at the 
		  web service provided for the number of requests.
		*/	
		//temp = "{\"count\": 3, \"results\": [{\"category\": \"power generation and storage\", \"client_record_id\": \"patent_LEW-18939-1\", \"trl\": \"3 - Proof-of-concept\", \"eRelations\": [], \"reference_number\": \"LEW-18939-1\", \"expiration_date\": \"\", \"abstract\": \"A magnetostrictive alternator configured to convert pressure waves into electrical energy is provided.  It should be appreciated that the magnetostrictive alternator may be combined in some embodiments with a Stirling engine to produce electrical power.  The Stirling engine creates the oscillating pressure wave and the magnetostrictive alternator converts the pressure wave into electricity.  In some embodiments, the magnetostrictive alternator may include aerogel material and magnetostrictive material.  The aerogel material may be configured to convert a higher amplitude pressure wave into a lower amplitude pressure wave.  The magnetostrictive material may be configured to generate an oscillating magnetic field when the magnetostrictive material is compressed by the lower amplitude pressure wave.\", \"title\": \"Magnetostrictive Alternator - Low cost, No moving part, High Efficiency, Oscillating Acoustic Pressure Wave to Electric Power Transducer\", \"innovator\": [{\"lname\": \"Dyson\", \"mname\": \"W.\", \"company\": \"NASA John H. Glenn Research Center At Lewis Field\", \"order\": \"1\", \"fname\": \"Rodger\"}, {\"lname\": \"Bruder\", \"mname\": \"A.\", \"company\": \"NASA John H. Glenn Research Center At Lewis Field\", \"order\": \"2\", \"fname\": \"Geoffrey\"}], \"contact\": {\"email\": \"ttp@grc.nasa.gov\", \"office\": \"Innovation Projects Office\", \"facility\": \"NASA Glenn Research Center\"}, \"publication\": null, \"concepts\": {\"1\": \"Fundamental physics concepts\", \"0\": \"Electromagnetism\", \"3\": \"Nikola Tesla\", \"2\": \"Waves\", \"5\": \"Electricity\", \"4\": \"Electric current\", \"7\": \"Wave\", \"6\": \"Heat engine\"}, \"serial_number\": \"13/916,797\", \"_id\": \"53f65ec45904da2c9fc30258\", \"id\": \"patent_LEW-18939-1\", \"center\": \"GRC\"}, {\"category\": \"electrical and electronics\", \"client_record_id\": \"patent_KSC-13285\", \"center\": \"KSC\", \"eRelations\": [], \"reference_number\": \"KSC-13285\", \"expiration_date\": \"\", \"abstract\": \"A system and method for detecting damage in an electrical wire, including     delivering at least one test electrical signal to an outer electrically     conductive material in a continuous or non-continuous layer covering an     electrically insulative material layer that covers an electrically     conductive wire core. Detecting the test electrical signals in the outer     conductive material layer to obtain data that is processed to identify     damage in the outer electrically conductive material layer.\", \"title\": \"Method of fault detection and rerouting\", \"innovator\": [{\"lname\": \"Medelius\", \"mname\": \"J.\", \"company\": \"ASRC Aerospace Corporation\", \"order\": \"1\", \"fname\": \"Pedro\"}, {\"lname\": \"Gibson\", \"mname\": \"L.\", \"company\": \"ASRC Aerospace Corporation\", \"order\": \"2\", \"fname\": \"Tracy\"}, {\"lname\": \"Lewis\", \"mname\": \"E.\", \"company\": \"NASA John F. Kennedy Space Center\", \"order\": \"3\", \"fname\": \"Mark\"}], \"contact\": {\"phone\": \"(321) 861-7158\", \"facility\": \"NASA Kennedy Space Center\", \"email\": \"KSC-DL-TechnologyTransfer@mail.nasa.gov\", \"office\": \"Innovative Partnerships Office\", \"address\": \"Kennedy Space Center, Kennedy Space Center, FL 32899\"}, \"publication\": [{\"type\": \"Report\", \"title\": \"Online Diagnostics Device (ODD)\"}], \"concepts\": {\"1\": \"English-language films\", \"0\": \"Electrical conductor\", \"3\": \"Electrical engineering\", \"2\": \"Electricity\", \"5\": \"Copper\", \"4\": \"Electric charge\", \"7\": \"Signal\", \"6\": \"Electric current\"}, \"serial_number\": \"12/843,382\", \"_id\": \"53f6596d5904da2c9fc2ffa6\", \"patent_number\": \"8593153\", \"id\": \"patent_KSC-13285\", \"trl\": \"4 - Validation in laboratory environment\"}, {\"category\": \"electrical and electronics\", \"client_record_id\": \"patent_MFS-32228-1\", \"center\": \"MSFC\", \"eRelations\": [], \"reference_number\": \"MFS-32228-1\", \"expiration_date\": \"\", \"abstract\": \"A short-range communication system includes an antenna, a transmitter,     and a receiver. The antenna is an electrical conductor formed as a planar     coil with rings thereof being uniformly spaced. The transmitter is spaced     apart from the plane of the coil by a gap. An amplitude-modulated and     asynchronous signal indicative of a data stream of known peak amplitude     is transmitted into the gap. The receiver detects the coil's resonance     and decodes same to recover the data stream.\", \"title\": \"Short-range communication system\", \"innovator\": [{\"lname\": \"Howard\", \"mname\": \"E.\", \"company\": \"NASA/Marshall Space Flight Center\", \"order\": \"1\", \"fname\": \"David\"}, {\"lname\": \"Smith\", \"mname\": \"A.\", \"company\": \"NASA/Marshall Space Flight Center\", \"order\": \"2\", \"fname\": \"Dennis\"}, {\"lname\": \"Alhorn\", \"mname\": \"C.\", \"company\": \"NASA/Marshall Space Flight Center\", \"order\": \"3\", \"fname\": \"Dean\"}], \"contact\": {\"name\": \"Sammy Nabors\", \"office\": \"Technology Transfer Office\", \"facility\": \"NASA Marshall Space Flight Center\", \"phone\": \"(256) 544-5226\", \"address\": \"Huntsville, AL 35812\", \"email\": \"Sammy.Nabors@nasa.gov\"}, \"publication\": null, \"concepts\": {\"1\": \"Electronics\", \"0\": \"Radio\", \"3\": \"Sound\", \"2\": \"Broadcasting\", \"5\": \"Electric charge\", \"4\": \"Electricity\", \"6\": \"Radar\"}, \"serial_number\": \"12/241,322\", \"_id\": \"53f659835904da2c9fc2ffb1\", \"patent_number\": \"8290435\", \"id\": \"patent_MFS-32228-1\", \"trl\": \"4 - Validation in laboratory environment\"}]}";
		
		JSONObject jobject = new JSONObject(target.request(MediaType.APPLICATION_JSON_TYPE).get(String.class));
				
		// Get items array
		JSONArray items = jobject.getJSONArray("results");
		
		List<String> inventors2 = new ArrayList<>();
		
		for (int i=0;i<items.length();i++){ 
					
		     JSONObject obj2 = (JSONObject)items.get(i);
		     JSONArray itemsInv = obj2.getJSONArray("innovator");
             for (int j=0;j<itemsInv.length();j++){ 
            	 JSONObject invObj = (JSONObject)itemsInv.get(j);
                 
                 log.debug(invObj.get("lname").toString()+invObj.get("fname").toString());
                 inventors2.add(invObj.get("lname").toString().trim()+invObj.get("fname").toString().trim());
              }
		}
		
		HashMap<String, String> invPalindromeResult = new HashMap<String,String>();
		//ArrayList<String> aListResult = new ArrayList<String>();
		for (int k = 0;k < inventors2.size();k++) {
            
            log.debug("Innovator name : "+k+"  "+inventors2.get(k));
            ArrayList<Character> list = new ArrayList<Character>();
            
            
            //ArrayList<Character> a=new ArrayList<Character>();
            for(int i=0;i<inventors2.get(k).length();i++)
            {
                list.add(inventors2.get(k).charAt(i));

            }
            
            HashSet<Character> hs = new HashSet<>();
            hs.addAll(list);
            list.clear();
            list.addAll(hs);
             
            double finalcount = getPalindromecount(list,inventors2.get(k).trim());
            //invPalindromeResult.put("\"name\": \""+inventors2.get(k).toString().trim()+"\"", " count: "+finalcount);
            invPalindromeResult.put(inventors2.get(k).toString().trim(), String.valueOf(finalcount));
            //aListResult.add("\"name\": \""+inventors2.get(k).toString().trim()+"\""+ " count: "+finalcount);
            
            
         }	
		 
		
	
		 return invPalindromeResult;
		//return aListResult;
		
		}
		catch(Exception e){
			e.printStackTrace();
			return null;
			
		}
		
	}

	public  double getPalindromecount(ArrayList<Character> list,String invName ){
		double count=0;
		int n= invName.length();
		int k = list.size();
		
		int exp;
		
		
		if(n%2 == 0){
			exp = n/2;
			if (exp != 1) {
		        count =  (k * Math.pow(k, exp - 1));
		    } else {
		        count = k;
		    }
			
		}
		else{
			exp = (n-1)/2;
			if (exp != 1) {
		        count =  (k * Math.pow(k, exp - 1));
		    } else {
		        count = k;
		    }
		}
		
		
		log.debug("Palindrome count: "+ (int)count);
		return count;
	}
	
	
	@Test
	public void testGetDefaultUser() throws IOException {
		
		//Client client = ClientBuilder.newClient();
		//WebTarget target = client.target("http://api.data.gov/nasa/patents/content?query=electricity&limit=3&api_key=DEMO_KEY");
			
		/*JSONObject jobject = new JSONObject(target.request(MediaType.APPLICATION_JSON_TYPE).get(String.class));
		 WebResource service = client.resource(getBaseURI());
         ClientResponse resp = service.path("rest").path("users")
                .accept(MediaType.APPLICATION_JSON)
                .get(ClientResponse.class);
         log.debug("Got stuff: " + jobject);
         String text = resp.getEntity(String.class);

         assertEquals(200, resp.getStatus());
         assertEquals("{\"firstName\":\"RadJonFromREST\",\"lastName\":\"TomFromREST\"}", text);
        
         */
    }
	
	//Below methods are coded when I was trying to create all possible pallindromes and writing to a data structure
	//But realized it was not an efficient way as it will write huge number of data and created instances of immutable string objects
	//resulting in heap space full and running for only one inventor name and running out of heap space and resulting in exception.
	//Thus used formula to obtain possible pallindrome counts.
	
	public ArrayList<String> sizeKPalindromes(ArrayList<Character> charSet, int size) {
		Boolean odd = false;
		
		log.debug((size & 1));
		if ( (size & 1) > 0 ) {/* odd */
			odd = true;
		}
		return sizeKPalindromes("", charSet, size,odd);
		
		
	}

	private ArrayList<String> sizeKPalindromes(String string, ArrayList<Character> charSet, int size, Boolean odd) { 
		if (string == null) {
			return null;
			
		}
		//int palCount=0;
		if (string.length() == size) {
			ArrayList<String> currPalindrome = new ArrayList<String>();
			currPalindrome.add(string);
			//palCount++;
			//log.debug("final palindrome count: "+palCount);
			return currPalindrome;
		}
		
		ArrayList<String> allPalindromeStrings = new ArrayList<String>();
		allPalindromeStrings.removeAll(allPalindromeStrings);
		
		for (int i = 0; i < size; i++) {
			
			StringBuffer tempString = new StringBuffer();
			
			if (odd && string.isEmpty()) {
				tempString.append(charSet.get(i)) ;//= string + charSet.get(i);
				
				
				
			}
			
			else {
				//tempString = charSet.get(i) + string + charSet.get(i);
				tempString.append(charSet.get(i) + string + charSet.get(i));
				
			}
			
			
			
			ArrayList<String> tempPalindromes = sizeKPalindromes(tempString.toString(), charSet, size, odd);
			
			allPalindromeStrings.addAll(tempPalindromes);
			
			
			
			
		}
		
		
		
		return allPalindromeStrings;
		
		
		
		
	}
	
	
	
}
