package com.zchallenge;
/**
 * @author rkadiri
 *
 */

import javax.ws.rs.Path;

import static org.junit.Assert.*;


import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.json.*;
import org.apache.log4j.*;
import org.junit.Test;

@Path("/palindromes/")
public class ZPalindromeService {
	
	
	static Logger log = Logger.getLogger(ZPalindromeService.class);
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	
	public JsonArray getInnovatorPalindrome(){
	
		
		HashMap<String,String> resultMap = new HashMap<String,String>();
		
		NasaPatentsInventorZillClient nasaPatentInventor = new NasaPatentsInventorZillClient();
		
		
		resultMap = nasaPatentInventor.getInventorNamePalindrome();
		
		
		//iterate through map and pick name values and create MyJAXBean objects
		//Iterator<Map.Entry<String,String>> it = resultMap.entrySet().iterator();
		JsonObjectBuilder invBuilder = Json.createObjectBuilder();
		Iterator<Map.Entry<String,String>> it1 = resultMap.entrySet().iterator();

		while (it1.hasNext()) {
		    log.info("Inside iterator");
		    Map.Entry<String,String> pair2 = (Map.Entry<String,String>)it1.next();
		    invBuilder.add("name:"+pair2.getKey().toString(),"count: "+pair2.getValue());
		 }
		    
		 //JsonObject invJsonObject = invBuilder.build();
		 JsonArray jsonArray2=Json.createArrayBuilder()
		            .add(invBuilder).build();
		    
		 //return invJsonObject;
		 return jsonArray2;

	}
	
	
	@Test
	
	  public void testGetMessage() {
	
	    SampleService service = new SampleService();
	    String message = service.getMessage();
	    assertEquals( "Testing", message );
	
	  }


}